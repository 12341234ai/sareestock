# SareeStock (Android starter)

A private, offline-first Android application foundation for tracking saree supplier offers and consolidated stock.

## Included in this first code drop
- Kotlin + Jetpack Compose Android app
- Room/SQLite local database
- Supplier group creation
- Import one supplier photo and enter its price
- Gallery of active offers
- Basic consolidated design quantity records
- Local image storage with resize/compression
- SHA-256 file hash and offline perceptual difference-hash matcher
- 30-day offer expiry timestamp and database cleanup worker foundation

## Important scope notes
This is a runnable foundation, not yet the complete final product specification. In particular, the current screens do not yet implement batch photo import, WhatsApp share intake, duplicate-review workflow, full reference-photo search UI, supplier-offer-to-design confirmation, selected purchase flow, individual piece records, backup/export, or storage dashboard. Do not treat those as completed.

Photo similarity uses a simple dHash heuristic. It is not AI and cannot guarantee that two images show the same design. A human must confirm every match.

## Open in Android Studio
1. Install the latest stable Android Studio.
2. Open this folder as a project.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

JDK 17 or newer is recommended. The app uses Android SDK 36.

## Data and privacy
- Database and imported photos stay in the app's private storage on the phone.
- No cloud backend or analytics SDK is configured.
- Uninstalling the app removes its private app data. Export/backup is not implemented yet.
- Offer expiry is stored as 30 days. Android background work is not exact-to-the-minute; the production implementation must run cleanup on app launch and before showing active data, as well as periodically in the background.
- The current worker removes expired database rows but does not yet remove their image files. A production cleanup repository must delete both rows and files transactionally/safely before release.

## Package
`com.sareestock.app`
