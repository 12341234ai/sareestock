package com.sareestock.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [SupplierGroup::class, Design::class, SupplierOffer::class, PurchaseSelection::class],
    version = 1,
    exportSchema = false
)
abstract class SareeDatabase : RoomDatabase() {
    abstract fun sareeDao(): SareeDao

    companion object {
        @Volatile private var INSTANCE: SareeDatabase? = null
        fun get(context: Context): SareeDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SareeDatabase::class.java,
                    "sareestock.db"
                ).build().also { INSTANCE = it }
            }
    }
}
