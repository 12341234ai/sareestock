package com.sareestock.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.sareestock.app.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = SareeDatabase.get(this)
        setContent { MaterialTheme { SareeStockApp(db.sareeDao()) } }
    }
}

@Composable
private fun SareeStockApp(dao: SareeDao) {
    var tab by remember { mutableStateOf("Groups") }
    Scaffold(
        topBar = { TopAppBar(title = { Text("SareeStock") }) },
        bottomBar = {
            NavigationBar {
                listOf("Groups", "Add Sarees", "Gallery", "Inventory", "Search").forEach { name ->
                    NavigationBarItem(
                        selected = tab == name,
                        onClick = { tab = name },
                        icon = {
                            Icon(
                                when (name) {
                                    "Groups" -> Icons.Default.Groups
                                    "Add Sarees" -> Icons.Default.Add
                                    "Gallery" -> Icons.Default.Collections
                                    "Inventory" -> Icons.Default.Inventory2
                                    else -> Icons.Default.Search
                                }, contentDescription = name
                            )
                        },
                        label = { Text(name) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            "Groups" -> GroupsScreen(dao, Modifier.padding(padding))
            "Add Sarees" -> AddOfferScreen(dao, Modifier.padding(padding))
            "Gallery" -> GalleryScreen(dao, Modifier.padding(padding))
            "Inventory" -> InventoryScreen(dao, Modifier.padding(padding))
            else -> SearchInfoScreen(Modifier.padding(padding))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GroupsScreen(dao: SareeDao, modifier: Modifier = Modifier) {
    val groups by dao.groups().collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Supplier groups", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(name, { name = it }, label = { Text("New supplier / WhatsApp group name") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { if (name.isNotBlank()) { scope.launch { dao.addGroup(SupplierGroup(name = name.trim())) }; name = "" } },
            modifier = Modifier.padding(top = 8.dp)
        ) { Text("Create group") }
        Spacer(Modifier.height(12.dp))
        LazyColumn { items(groups) { group ->
            ListItem(headlineContent = { Text(group.name) }, supportingContent = { Text("Supplier group") })
            HorizontalDivider()
        } }
    }
}

@Composable
private fun AddOfferScreen(dao: SareeDao, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val groups by dao.groups().collectAsState(initial = emptyList())
    var selectedGroup by remember { mutableStateOf<Long?>(null) }
    var price by remember { mutableStateOf("") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var message by remember { mutableStateOf("Choose a group, photo and price.") }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { pickedUri = it }
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Add supplier offer", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        if (groups.isEmpty()) Text("Create a supplier group first in the Groups tab.")
        else groups.forEach { group ->
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                RadioButton(selectedGroup == group.id, { selectedGroup = group.id })
                Text(group.name)
            }
        }
        OutlinedTextField(price, { price = it }, label = { Text("Supplier price") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { picker.launch("image/*") }, modifier = Modifier.padding(top = 8.dp)) {
            Text(if (pickedUri == null) "Choose photo" else "Change photo")
        }
        pickedUri?.let { AsyncImage(model = it, contentDescription = "Selected saree", modifier = Modifier.size(140.dp)) }
        Button(onClick = {
            val groupId = selectedGroup
            val amount = price.toDoubleOrNull()
            val uri = pickedUri
            if (groupId == null || amount == null || amount < 0 || uri == null) {
                message = "Select a group, enter a valid price and choose a photo."
            } else {
                scope.launch {
                    runCatching {
                        val (path, hash) = PhotoStore(context).import(uri)
                        dao.addOffer(SupplierOffer(groupId = groupId, imagePath = path, price = amount, imageHash = hash))
                    }.onSuccess { message = "Offer saved." }
                     .onFailure { message = "Could not save photo: ${it.message}" }
                }
            }
        }, modifier = Modifier.padding(top = 8.dp)) { Text("Save offer") }
        Text(message, modifier = Modifier.padding(top = 8.dp))
        Text("Offers and prices expire after 30 days. Keep the selected purchase record separately.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun GalleryScreen(dao: SareeDao, modifier: Modifier = Modifier) {
    val offers by dao.activeOffers().collectAsState(initial = emptyList())
    LazyColumn(modifier.fillMaxSize().padding(12.dp)) {
        item { Text("Active supplier photos", style = MaterialTheme.typography.titleLarge) }
        items(offers) { offer ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                AsyncImage(model = offer.imagePath, contentDescription = "Saree offer", modifier = Modifier.size(92.dp))
                Column(Modifier.padding(start = 12.dp)) {
                    Text("Offer #${offer.id}")
                    Text("Price: ${"%.2f".format(offer.price)}")
                    Text("Expires: ${java.text.SimpleDateFormat("MMM d, yyyy").format(java.util.Date(offer.expiresAt))}")
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable
private fun InventoryScreen(dao: SareeDao, modifier: Modifier = Modifier) {
    val designs by dao.designs().collectAsState(initial = emptyList())
    var code by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }
    val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Consolidated inventory", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(code, { code = it }, label = { Text("Design code (e.g. SS0001)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(quantity, { quantity = it }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val qty = quantity.toIntOrNull()
            if (code.isNotBlank() && qty != null && qty >= 0) {
                scope.launch { dao.addDesign(Design(code = code.trim(), quantity = qty)) }
                code = ""; quantity = "1"
            }
        }, modifier = Modifier.padding(vertical = 8.dp)) { Text("Add design to inventory") }
        LazyColumn { items(designs) { d ->
            ListItem(headlineContent = { Text(d.code) }, supportingContent = { Text("Quantity: ${d.quantity}") })
            HorizontalDivider()
        } }
    }
}

@Composable
private fun SearchInfoScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Photo Search", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text("The offline dHash matching engine is included in matching/PhotoMatcher.kt. The next UI step is to connect a reference-photo picker to active offers and display ranked candidates.")
        Spacer(Modifier.height(8.dp))
        Text("Important: image similarity is only a suggestion. Confirm matches yourself; folds, angles and lighting can change results.")
    }
}
