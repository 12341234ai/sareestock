package com.sareestock.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "supplier_groups")
data class SupplierGroup(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "designs")
data class Design(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val quantity: Int = 0,
    val individualPieceTracking: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "offers")
data class SupplierOffer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val groupId: Long,
    val designId: Long? = null,
    val imagePath: String,
    val price: Double,
    val imageHash: String,
    val addedAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000
)

@Entity(tableName = "purchases")
data class PurchaseSelection(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val designId: Long,
    val offerId: Long,
    val selectedPrice: Double,
    val selectedAt: Long = System.currentTimeMillis()
)
