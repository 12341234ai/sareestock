package com.sareestock.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest

class PhotoStore(private val context: Context) {
    private val folder = File(context.filesDir, "supplier_photos").apply { mkdirs() }

    fun import(uri: Uri): Pair<String, String> {
        val source = context.contentResolver.openInputStream(uri)
            ?: error("Could not open selected photo")
        val bitmap = source.use { BitmapFactory.decodeStream(it) }
            ?: error("Unsupported or damaged image")
        val scaled = scaleDown(bitmap, 1600)
        val file = File(folder, "offer_${System.currentTimeMillis()}_${(1000..9999).random()}.jpg")
        FileOutputStream(file).use { out ->
            scaled.compress(Bitmap.CompressFormat.JPEG, 84, out)
        }
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(file.readBytes()).joinToString("") { "%02x".format(it) }
        if (scaled !== bitmap) scaled.recycle()
        bitmap.recycle()
        return file.absolutePath to hash
    }

    fun delete(path: String) {
        runCatching { File(path).delete() }
    }

    private fun scaleDown(bitmap: Bitmap, max: Int): Bitmap {
        val longest = maxOf(bitmap.width, bitmap.height)
        if (longest <= max) return bitmap
        val ratio = max.toFloat() / longest
        return Bitmap.createScaledBitmap(
            bitmap, (bitmap.width * ratio).toInt(), (bitmap.height * ratio).toInt(), true
        )
    }
}
