package com.sareestock.app.matching

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.BitmapFactory
import java.io.File

/**
 * Lightweight offline dHash matcher. This is a candidate finder, not proof that
 * two photos show the same saree design. Human confirmation is required.
 */
object PhotoMatcher {
    fun differenceHash(bitmap: Bitmap): Long {
        val small = Bitmap.createScaledBitmap(bitmap, 9, 8, true)
        var hash = 0L
        var bit = 0
        for (y in 0 until 8) {
            for (x in 0 until 8) {
                val left = luminance(small.getPixel(x, y))
                val right = luminance(small.getPixel(x + 1, y))
                if (left > right) hash = hash or (1L shl bit)
                bit++
            }
        }
        if (small !== bitmap) small.recycle()
        return hash
    }

    fun hashFile(path: String): Long? = runCatching {
        val bitmap = BitmapFactory.decodeFile(path) ?: return null
        differenceHash(bitmap).also { bitmap.recycle() }
    }.getOrNull()

    fun distance(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    fun rank(reference: Long, candidates: List<Pair<Long, String>>): List<Pair<String, Int>> =
        candidates.map { (hash, path) -> path to distance(reference, hash) }
            .sortedBy { it.second }

    private fun luminance(color: Int): Int =
        (Color.red(color) * 299 + Color.green(color) * 587 + Color.blue(color) * 114) / 1000
}
