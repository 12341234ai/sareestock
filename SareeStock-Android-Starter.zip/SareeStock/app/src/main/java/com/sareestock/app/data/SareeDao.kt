package com.sareestock.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SareeDao {
    @Query("SELECT * FROM supplier_groups ORDER BY name COLLATE NOCASE")
    fun groups(): Flow<List<SupplierGroup>>

    @Insert
    suspend fun addGroup(group: SupplierGroup): Long

    @Query("SELECT * FROM offers WHERE expiresAt > :now ORDER BY addedAt DESC")
    fun activeOffers(now: Long = System.currentTimeMillis()): Flow<List<SupplierOffer>>

    @Query("SELECT * FROM offers WHERE groupId = :groupId AND expiresAt > :now ORDER BY addedAt DESC")
    fun offersForGroup(groupId: Long, now: Long = System.currentTimeMillis()): Flow<List<SupplierOffer>>

    @Insert
    suspend fun addOffer(offer: SupplierOffer): Long

    @Query("SELECT * FROM designs ORDER BY id DESC")
    fun designs(): Flow<List<Design>>

    @Insert
    suspend fun addDesign(design: Design): Long

    @Update
    suspend fun updateDesign(design: Design)

    @Insert
    suspend fun selectPurchase(purchase: PurchaseSelection)

    @Query("DELETE FROM offers WHERE expiresAt <= :now")
    suspend fun deleteExpiredOffers(now: Long = System.currentTimeMillis()): Int

    @Query("SELECT * FROM offers WHERE id = :id LIMIT 1")
    suspend fun offerById(id: Long): SupplierOffer?

    @Query("SELECT * FROM designs WHERE id = :id LIMIT 1")
    suspend fun designById(id: Long): Design?
}
