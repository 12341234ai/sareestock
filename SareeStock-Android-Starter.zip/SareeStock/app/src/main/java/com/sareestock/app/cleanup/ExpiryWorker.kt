package com.sareestock.app.cleanup

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.sareestock.app.data.SareeDatabase
import java.io.File

class ExpiryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        val dao = SareeDatabase.get(applicationContext).sareeDao()
        // The database deletion is authoritative. Photo files are removed by the
        // repository cleanup routine on app launch; worker keeps DB expiry moving.
        dao.deleteExpiredOffers()
        Result.success()
    }.getOrElse { Result.retry() }
}
