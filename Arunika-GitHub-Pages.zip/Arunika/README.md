# Arunika Saree Organizer

A responsive, installable, static web app for managing supplier saree offers, design IDs, and individual purchased inventory. All business data and photographs stay in your browser's IndexedDB storage. There is no backend, account system, paid API, or cloud sync.

## Included
- Supplier group create/rename/delete (duplicate names blocked)
- Multiple image uploads with image resizing and separate per-image ₹ offer prices
- Gallery search, filtering, sorting, design ID assignment, and offer removal
- Photo Search using SHA-256 exact file comparison (for normalized identical files), difference hash and color histogram ranking; no AI; results are approximate and never auto-merge
- Individually numbered inventory pieces (`AR0001`, etc.) with separate actual purchase prices and dates
- Inventory search, group filtering, sorting, detail viewing, deletion, and purchase total
- 30-day offer expiry check on launch and while app remains active (not while browser is closed); inventory is retained
- Full JSON backup/restore with image data and inventory-number uniqueness checks
- Clear-all confirmation
- Beginner How-to page
- PWA manifest and service worker shell cache

## GitHub Pages deployment
1. Download and extract this project folder (`Arunika`) locally.
2. Copy the contents inside `Arunika/` to your repository root (the folder with your `README.md`, if you want the site root at the repository path).
3. Commit and push:
   ```bash
   git add .
   git commit -m "Build Arunika saree management website"
   git push
   ```
4. In GitHub, open **Settings → Pages → Deploy from a branch → main → /(root)**.
5. Your site should be available at `https://12341234ai.github.io/sareestock/` once GitHub Pages finishes deploying.

No build step is needed. Relative paths are used for project-subdirectory hosting.

## Install on Android
Open the deployed page in Chrome, use the browser menu, and choose **Install app** or **Add to Home screen** (wording varies by device).

## Local preview
You may open `index.html` directly, but service workers/PWA installation require a secure context (HTTPS or localhost). For testing, use a simple static server or GitHub Pages.

## Data and privacy notes
- Stored in the current browser profile and device using IndexedDB.
- Browser refresh and normal closure generally retain data; clearing site data may erase it.
- Incognito/private mode is not suitable for long-term data.
- No automatic cross-device synchronization or cloud backup.
- GitHub Pages only hosts code, not records.
- Backup regularly using Settings → Export Backup and keep the file safe.
- Browser-only 30-day expiry runs on app launch and while the app is active; it cannot run when the browser is closed.
- Similar-photo scoring is heuristic; confirm matches manually.

## Source files
- `index.html` — app shell
- `style.css` — layout and theme
- `app.js` — data operations and page logic
- `manifest.json` — PWA metadata
- `sw.js` — offline shell cache
- `assets/icon.svg` — app icon

## Compatibility
Modern browsers with IndexedDB, Canvas, FileReader, and (for SHA-256 matching) Web Crypto. If Web Crypto is unavailable, SHA-256 exact comparison is skipped; visual hash/color ranking remains.
